from django.contrib import admin
from Fuel.models import FuelCompany, FuelCase

admin.site.register(FuelCompany)
admin.site.register(FuelCase)
